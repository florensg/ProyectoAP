package com.ap.ap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApApplicationTests {

	@Test
	void contextLoads() {
	}

}
